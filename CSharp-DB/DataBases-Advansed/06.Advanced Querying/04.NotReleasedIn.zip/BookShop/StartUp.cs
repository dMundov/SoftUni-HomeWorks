﻿namespace BookShop
{
    using BookShop.Models.Enums;
   
    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            
        }
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var notReleasedBook = context
                .Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .ToList();

            var result = new StringBuilder();

            foreach (var book in notReleasedBook)
            {
                result.AppendLine(book.Title);
            }

            return result.ToString().TrimEnd();
        }
        
    }
}
