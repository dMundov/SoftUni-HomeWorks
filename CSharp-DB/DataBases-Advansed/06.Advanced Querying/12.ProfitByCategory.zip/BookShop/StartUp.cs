﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var categories = context
                .Categories
                .Select(c => new
                {
                    c.Name,
                    TotalProfit = c.CategoryBooks
                        .Select(cb => cb.Book)
                        .Sum(b => b.Price * b.Copies)
                })
                .OrderByDescending(c => c.TotalProfit)
                .ThenBy(c => c.Name)
                .ToList();

            var resultToPrint = new StringBuilder();

            foreach (var category in categories)
            {
                resultToPrint.AppendLine($"{category.Name} ${category.TotalProfit}");
            }

            return resultToPrint.ToString().TrimEnd();
        }


    }
}

