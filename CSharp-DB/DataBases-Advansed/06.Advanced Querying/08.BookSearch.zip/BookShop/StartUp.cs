﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            var bookTitles = context
                .Books
                .Where(b => b.Title.ToLower()
                    .Contains(input.ToLower()))
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToList();

            var resultToPrint = new StringBuilder();

            foreach (var title in bookTitles)
            {
                resultToPrint.AppendLine(title);
            }

            return resultToPrint.ToString().TrimEnd();
        }

    }
}

