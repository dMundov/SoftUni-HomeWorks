﻿namespace BookShop
{
    using BookShop.Models.Enums;
   
    using Data;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
           
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBookTitles = context
                .Books
                .Where(b => b.EditionType == EditionType.Gold && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            var result = new StringBuilder();

            foreach (var book in goldenBookTitles)
            {
                result.AppendLine(book);
            }
            return result.ToString().TrimEnd();
        }
    }
}
