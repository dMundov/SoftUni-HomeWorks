﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {

            var inputDate = Console.ReadLine();

            var db = new BookShopContext();
            Console.WriteLine(GetBooksReleasedBefore(db,inputDate));

        }
         public static string GetBooksReleasedBefore(BookShopContext context, string date)

        {
            var newDateParts = date.Split('-');

            var day = int.Parse(newDateParts[0]);
            var month = int.Parse(newDateParts[1]);
            var year = int.Parse(newDateParts[2]);

            var dateToCheck = new DateTime(year, month, day);

            var booksTitles = context
                .Books
                .Where(b => b.ReleaseDate < dateToCheck)
                .OrderByDescending(b => b.ReleaseDate)
                .Select(b => new
                {
                    b.Title,
                    b.EditionType,
                    b.Price
                })
                .ToList();

            var resultToPrint = new StringBuilder();

            foreach (var book in booksTitles)
            {
                resultToPrint.AppendLine($"{book.Title} - {book.EditionType} - ${book.Price:F2}");
            }

            return resultToPrint.ToString().TrimEnd();
        }
    }
}
