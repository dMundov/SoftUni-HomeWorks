﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {

        }
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var inputCategories = input
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(bc => bc.ToLower())
                .ToArray();

            var titlesByCategory = context
                .BooksCategories
                .Where(bc =>
                inputCategories.Contains(bc.Category.Name.ToLower()))
                .Select(bc => bc.Book.Title)
                .OrderBy(b => b)
                .ToList();

            var resultToPrint = new StringBuilder();


            foreach (var bookTitle in titlesByCategory)
            {
                resultToPrint.AppendLine(bookTitle);
            }

            return resultToPrint.ToString().TrimEnd();
        }
    }
}
