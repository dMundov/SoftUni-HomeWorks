﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new CarDealerContext();

            var carsJson = File.ReadAllText(@"..\..\..\Datasets\cars.json");

            Console.WriteLine(ImportCars(context, carsJson));

        }
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var cars = JsonConvert.DeserializeObject<CarDto[]>(inputJson);

            foreach (var car in cars)
            {
                var newcar = new Car
                {
                    Make = car.Make,
                    Model = car.Model,
                    TravelledDistance = car.TravelledDistance
                };


                context.Cars.AddRange(newcar);

                foreach (var partId in car.PartsId)
                {
                    var partCar = new PartCar
                    {

                        CarId = newcar.Id,
                        PartId = partId
                    };
                    if (newcar.PartCars.FirstOrDefault(pc => pc.PartId == partId) == null)
                    {
                        context.PartCars.Add(partCar);
                    }
                }
            }
            context.SaveChanges();

            return $"Successfully imported {cars.Length}.";
        }
    }
}