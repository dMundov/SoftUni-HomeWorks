﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new ProductShopContext();
           
            var userJson = File.ReadAllText(@"..\..\..\Datasets\users.json");
            
            Console.WriteLine(ImportUsers(context, userJson));

        }

        public static string ImportUsers(ProductShopContext context, string inputJson)
        {


            User[] usersToImport = JsonConvert.DeserializeObject<User[]>(inputJson)
                .Where(u => u.LastName != null && u.LastName.Length >= 3)
                .ToArray();

            context.AddRange(usersToImport);
            context.SaveChanges();

            return $"Successfully imported {usersToImport.Length}";
        }


    }
}