﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new CarDealerContext();

            var customersToImport = File.ReadAllText(@"..\..\..\Datasets\sales.json");

            Console.WriteLine(ImportSales(context, customersToImport));

        }
         public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var sales = JsonConvert.DeserializeObject<Sale[]>(inputJson);
           
            
            context.Sales.AddRange(sales);     
            context.SaveChanges();

            return $"Successfully imported {sales.Length}.";
        }
    }
}