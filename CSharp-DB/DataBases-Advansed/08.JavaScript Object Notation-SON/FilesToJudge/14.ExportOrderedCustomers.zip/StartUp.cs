﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            using var context = new CarDealerContext();
            var customersToExport = GetOrderedCustomers(context);
            Console.WriteLine(customersToExport);
        }
        public static string GetOrderedCustomers(CarDealerContext context)
        {

            var customers = context
                .Customers
                .OrderBy(c => c.BirthDate)
                .ThenBy(c => c.IsYoungDriver)
                .Select(c => new
                {
                    c.Name,
                    BirthDate = c.BirthDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                    c.IsYoungDriver
                })
                .ToList();

            var customersJsonExport = JsonConvert.SerializeObject(customers, Formatting.Indented);

            return customersJsonExport;
        }


    }
}