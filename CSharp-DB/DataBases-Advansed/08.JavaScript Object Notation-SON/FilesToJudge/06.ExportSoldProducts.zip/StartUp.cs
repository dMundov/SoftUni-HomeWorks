﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Dtos.Export;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new ProductShopContext();

            Console.WriteLine( GetSoldProducts(context));



        }

        public static string GetSoldProducts(ProductShopContext context)
        {
            var usersAndProducts = context
                .Users
                .Where(u => u.ProductsSold.Any(ps => ps.Buyer != null))
                .Select(u => new
                {
                    firstName = u.FirstName,
                    lastName = u.LastName,
                    soldProducts = u.ProductsSold
                            .Where(ps => ps.Buyer != null)
                            .Select(sp => new
                            {
                                name = sp.Name,
                                price = sp.Price,
                                buyerFirstName = sp.Buyer.FirstName,
                                buyerLastName = sp.Buyer.LastName

                            })


                })
                .OrderBy(u => u.lastName)
                .ThenBy(u => u.firstName)
                .ToList();


            var usersJson = JsonConvert.SerializeObject(usersAndProducts, Formatting.Indented);
            
            return usersJson;


        }



    }
}