﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.DTO.ExportDtos;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            using var context = new CarDealerContext();
            var customersToExport = GetCarsWithTheirListOfParts(context);
            Console.WriteLine(customersToExport);
        }
        public static string GetCarsWithTheirListOfParts(CarDealerContext context)
        {

            var carsParts = context
                .Cars
                .Select(c => new
                {
                    car = new
                    {
                        c.Make,
                        c.Model,
                        c.TravelledDistance
                    },
                    parts = c.PartCars
                    .Select(p => new ExportPartDto
                    {
                        Name = p.Part.Name,
                        Price = $"{p.Part.Price:F2}"
                    })
                    .ToList()
                })
                .ToList();


            var carsPartsJason = JsonConvert.SerializeObject(carsParts, Formatting.Indented);

            return carsPartsJason;
        }

    }
}