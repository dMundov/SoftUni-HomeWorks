﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.DTO.ExportDtos;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            using var context = new CarDealerContext();
            var customersToExport = GetTotalSalesByCustomer(context);
            Console.WriteLine(customersToExport);
        }
        public static string GetTotalSalesByCustomer(CarDealerContext context)
        {

            var customersSales = context
                .Customers
                .Where(c => c.Sales.Any(s => s.Car != null))
                .Select(c => new
                {
                    fullName = c.Name,
                    boughtCars = c.Sales.Count(s => s.Car != null),
                    spentMoney = c.Sales
                        .SelectMany(s => s.Car.PartCars)
                        .Sum(p => p.Part.Price)
                })
                .OrderByDescending(c=>c.spentMoney)
                .ThenByDescending(c=>c.boughtCars)
                .ToList();


            var carsPartsJason = JsonConvert.SerializeObject(customersSales, Formatting.Indented);

            return carsPartsJason;
        }

    }
}