﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new ProductShopContext();

            var categoriesProductJson = File.ReadAllText(@"..\..\..\Datasets\categories-products.json");

            Console.WriteLine(ImportCategoryProducts(context, categoriesProductJson));

        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {


            CategoryProduct[] categoriesProductsToImport = JsonConvert.DeserializeObject<CategoryProduct[]>(inputJson)
                .Where(cp => cp.CategoryId != null
                          && cp.ProductId != null)
                .ToArray();

            context.AddRange(categoriesProductsToImport);
            context.SaveChanges();


            return $"Successfully imported {categoriesProductsToImport.Length}";
        }


    }
}