﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            using var context = new CarDealerContext();
            var customersToExport = GetLocalSuppliers(context);
            Console.WriteLine(customersToExport);
        }
        public static string GetLocalSuppliers(CarDealerContext context)
        {

            var localSupliers = context
                .Suppliers
                .Where(s => s.IsImporter == false)
                .Select(s => new
                {
                    s.Id,
                    s.Name,
                    PartsCount = s.Parts.Count()
                })
                .ToList();




            var localSupplJason = JsonConvert.SerializeObject(localSupliers, Formatting.Indented);

            return localSupplJason;
        }

    }
}