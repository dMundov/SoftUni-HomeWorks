﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            using var context = new CarDealerContext();
            var customersToExport = GetCarsFromMakeToyota(context);
            Console.WriteLine(customersToExport);
        }
        public static string GetCarsFromMakeToyota(CarDealerContext context)
        {
            var toyotaCars = context
                .Cars
                .Where(c => c.Make == "Toyota")
                .Select(c => new
                {
                    c.Id,
                    c.Make,
                    c.Model,
                    c.TravelledDistance
                })
                .OrderBy(c => c.Model)
                .ThenByDescending(c => c.TravelledDistance)
                .ToList();

               
            var carsToyotaJsonExport = JsonConvert.SerializeObject(toyotaCars, Formatting.Indented);

            return carsToyotaJsonExport;
        }

    }
}