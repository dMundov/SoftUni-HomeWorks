﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new ProductShopContext();

            var categoriesJson = File.ReadAllText(@"..\..\..\Datasets\categories.json");

            Console.WriteLine(ImportCategories(context, categoriesJson));

        }

        public static string ImportCategories(ProductShopContext context, string inputJson)
        {


            Category[] categoriesToImport = JsonConvert.DeserializeObject<Category[]>(inputJson)
                .Where(c=> c.Name!= null)
                .ToArray();

            context.AddRange(categoriesToImport);
            context.SaveChanges();

            
            return $"Successfully imported {categoriesToImport.Length}";
        }


    }
}