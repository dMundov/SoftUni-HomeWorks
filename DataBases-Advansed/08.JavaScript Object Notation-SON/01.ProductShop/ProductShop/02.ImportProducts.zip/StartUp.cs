﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var context = new ProductShopContext();

            var productsJson = File.ReadAllText(@"..\..\..\Datasets\products.json");

            Console.WriteLine(ImportProducts(context, productsJson));

        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {


            Product[] productsToImport = JsonConvert.DeserializeObject<Product[]>(inputJson)
                .Where(p => p.Name.Length >= 3
                                    && p.Price != null
                                    && p.SellerId != null)
                .ToArray();

            context.AddRange(productsToImport);
            context.SaveChanges();

            return $"Successfully imported {productsToImport.Length}";
        }


    }
}