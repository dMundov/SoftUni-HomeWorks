﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static int RemoveBooks(BookShopContext context)
        {
            var booksToRemove = context
                .Books
                .Where(b => b.Copies < 4200)
                .ToList();

            var removedBooks = booksToRemove.Count;

            context.Books.RemoveRange(booksToRemove);

            context.SaveChanges();

            return removedBooks;
        }
    }
}

