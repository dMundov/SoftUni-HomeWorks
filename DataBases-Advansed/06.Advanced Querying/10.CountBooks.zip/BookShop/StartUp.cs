﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static int CountBooks(BookShopContext context, int length)
        {
            int booksCount = context
                .Books
                .Where(b => b.Title.Length > length)
                .Count();

            return booksCount;
        }

    }
}

