﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static string CountCopiesByAuthor(BookShopContext context)
        {
            var authors = context
               .Authors
               .Select(a => new
               {
                   a.FirstName,
                   a.LastName,
                   BookCopiesForAuthor = a.Books
                       .Sum(b => b.Copies)
               })
               .OrderByDescending(a => a.BookCopiesForAuthor)
               .ToList();

            var resultToPrint = new StringBuilder();

            foreach (var author in authors)
            {
                resultToPrint.AppendLine($"{author.FirstName} {author.LastName} - {author.BookCopiesForAuthor}");
            }

            return resultToPrint.ToString().TrimEnd();


        }

    }
}

