﻿namespace BookShop
{
    using BookShop.Models.Enums;

    using Data;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
        }
        public static void IncreasePrices(BookShopContext context)
        {
            var booksPriceToIncrease = context
                .Books
                .Where(b => b.ReleaseDate.Value.Year < 2010)
                .ToList();

            foreach (var book in booksPriceToIncrease)
            {
                book.Price += 5;
            }

            context.SaveChanges();
        }
    }
}

