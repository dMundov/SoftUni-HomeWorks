﻿namespace BookShop
{
    using BookShop.Models.Enums;
   
    using Data;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            var bookData = new BookShopContext();

            System.Console.WriteLine(GetBooksByPrice(bookData));
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context
            .Books
            .Where(b => b.Price > 40)
            .Select(b => new
            {
                b.Title,
                b.Price
            })
            .OrderByDescending(b => b.Price)
            .ToList();

            var result = new StringBuilder();

            foreach (var book in books)
            {
                result.AppendLine($"{book.Title} - ${book.Price:F2}");
            }
            return result.ToString().TrimEnd();

        }
    }
}
